En ES6, la plus simple façon de faire du traitement asynchrone est d'utiliser des **promesses**

## 1. Les promesses brisées

Etiam ornare pellentesque est id pretium. Vivamus nec luctus mauris. Pellentesque efficitur a nisi sit amet faucibus. Nam feugiat elit vel mauris venenatis rhoncus. Maecenas interdum nibh ut justo tempus feugiat. Nam interdum, nisi nec vestibulum tincidunt, mauris diam convallis mauris, nec dictum purus tellus at augue. Pellentesque malesuada arcu justo, et finibus ligula faucibus eget. Duis eleifend nunc rhoncus rutrum dignissim. Donec luctus, nisl quis egestas semper, tellus odio bibendum massa, nec condimentum neque urna sed tortor. Cras in neque ac ex ultrices commodo. Cras at congue erat.

## 2. Les belles promesses

**Donec ultrices neque sit amet accumsan tincidunt**. Maecenas consectetur, nunc sit amet semper semper, massa ligula ornare mi, quis auctor libero sapien in ligula. Aliquam erat volutpat. Proin sit amet eros magna. Fusce vitae tortor nec leo finibus finibus. In pharetra dolor ut nunc ultrices consectetur non et lacus. Sed mattis maximus condimentum. Mauris ac sapien quam. Cras pharetra ultrices diam non sodales. Nulla sed lacus at eros sodales facilisis sed ut augue. Donec rhoncus, ante vel dictum tincidunt, justo nisi pellentesque purus, a vestibulum mauris felis at nibh. Cras nec mi lacinia, tempor lorem quis, sodales augue. Mauris elementum risus feugiat libero faucibus interdum. Morbi pulvinar et purus eget euismod.

## 3. Les promesses de campagne

 1. Duis eget justo lacinia, tincidunt dolor in, iaculis dolor. Suspendisse sit amet lacus mattis, blandit eros eget, condimentum augue. Aenean maximus fermentum efficitur.
 1. Nam vehicula gravida nisi, quis laoreet elit laoreet sed.
 1. Quisque sit amet elit ut diam facilisis finibus et sed magna. Aenean in nunc convallis, suscipit libero nec, eleifend nunc. Ut at vulputate est. In eget consequat nisl. 