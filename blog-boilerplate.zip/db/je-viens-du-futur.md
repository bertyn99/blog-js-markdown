 Cet article a été écrit depuis *le futur*! **Ici, c'est le week-end!**

 ## Premier paragraphe du week-end
 
Lorem ipsum dolor sit amet, consectetur adipiscing elit. In bibendum, mauris id finibus euismod, turpis lectus feugiat sapien, non hendrerit urna magna sit amet velit. Duis malesuada dignissim metus ac tempor. Praesent elit lacus, dapibus id sagittis ut, dictum vitae sapien. Fusce ut tellus vel odio euismod vestibulum. Vivamus dictum molestie magna vitae lobortis. Suspendisse nec metus id turpis sagittis aliquet vitae ac nibh. Donec sit amet nunc varius, faucibus lectus eget, congue diam. Aenean mollis porttitor facilisis. Nam congue, orci non dapibus vestibulum, justo metus pellentesque lectus, id elementum lectus augue vitae odio. Fusce sit amet elit id tortor venenatis rhoncus. Ut nibh sapien, varius vitae nisl et, scelerisque posuere ante. Sed vel ullamcorper tellus. Suspendisse elementum posuere quam. Quisque pellentesque ultrices turpis, sed placerat urna dapibus eget. Phasellus ligula orci, sollicitudin quis turpis ut, vestibulum commodo sapien.

## Deuxième paragraphe du week-end

In nec massa eget velit consequat pellentesque a eu felis. Vivamus in nibh vitae magna suscipit efficitur. Duis non tellus sit amet tellus pellentesque cursus in at ante. Morbi vitae lorem consequat, ultricies augue ac, tincidunt elit. Nullam elementum enim a nisl suscipit viverra. Fusce in tempor augue. Ut faucibus commodo sodales. **Donec in augue feugiat, feugiat quam in, volutpat ante. Aenean nec ante dui.** Integer eget augue vitae metus egestas dictum. Nulla tempus fringilla condimentum. Vivamus eget cursus eros. Praesent mollis accumsan rhoncus.


## Troisième paragraphe du week-end

Etiam ornare pellentesque est id pretium. Vivamus nec luctus mauris. Pellentesque efficitur a nisi sit amet faucibus. Nam feugiat elit vel mauris venenatis rhoncus. Maecenas interdum nibh ut justo tempus feugiat. *Nam interdum, nisi nec vestibulum tincidunt*, mauris diam convallis mauris, nec dictum purus tellus at augue. Pellentesque malesuada arcu justo, et finibus ligula faucibus eget. Duis eleifend nunc rhoncus rutrum dignissim. Donec luctus, nisl quis egestas semper, tellus odio bibendum massa, nec condimentum neque urna sed tortor. Cras in neque ac ex ultrices commodo. Cras at congue erat. 