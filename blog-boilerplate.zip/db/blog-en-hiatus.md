C'est bientôt les fêtes, et je dois donc mettre ce blog en pause.

**Mais je reviendrai bientôt pour publier la suite de *Notre Dame de Nantes*!**

Un extrait pour vous faire patienter:

La bande entière éclata.

— Holàhée ! qui chante cette gamme ? quel est le chat-huant de malheur ?

— Tiens, je le reconnais, dit l’un ; c’est maître Andry Musnier.

— Parce qu’il est un des quatre libraires jurés de l’Université ! dit l’autre.

— Tout est par quatre dans cette boutique, cria un troisième : les quatre nations, les quatre facultés, les quatre fêtes, les quatre procureurs, les quatre électeurs, les quatre libraires.

— Eh bien, reprit Jean Frollo, il faut leur faire le diable à quatre.

— Musnier, nous brûlerons tes livres.

— Musnier, nous battrons ton laquais.

— Musnier, nous chiffonnerons ta femme.

— La bonne grosse mademoiselle Oudarde.

— Qui est aussi fraîche et aussi gaie que si elle était veuve.

— Que le diable vous emporte ! grommela maître Andry Musnier.

— Maître Andry, reprit Jehan, toujours pendu à son chapiteau, tais-toi, ou je te tombe sur la tête !

Maître Andry leva les yeux, parut mesurer un instant la hauteur du pilier, la pesanteur du drôle, multiplia mentalement cette pesanteur par le carré de la vitesse, et se tut.

Jehan, maître du champ de bataille, poursuivit avec triomphe :

— C’est que je le ferais, quoique je sois frère d’un archidiacre !

— Beaux sires, que nos gens de l’Université ! n’avoir seulement pas fait respecter nos privilèges dans un jour comme celui-ci ! Enfin, il y a mai et feu de joie à la Ville ; mystère, pape des fous et ambassadeurs flamands à la Cité ; et à l’Université, rien !

— Cependant la place Maubert est assez grande ! reprit un des clercs cantonnés sur la table de la fenêtre.

— À bas le recteur, les électeurs et les procureurs ! cria Joannes.

— Il faudra faire un feu de joie ce soir dans le Champ-Gaillard, poursuivit l’autre, avec les livres de maître Andry.

— Et les pupitres des scribes ! dit son voisin.

— Et les verges des bedeaux !

— Et les crachoirs des doyens !

— Et les buffets des procureurs !

— Et les huches des électeurs !

— Et les escabeaux du recteur ! 

**A suivre...**